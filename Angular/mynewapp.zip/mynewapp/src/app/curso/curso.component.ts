import { Component, OnInit } from '@angular/core';
import { Curso } from './curso';
import { CursoService } from './curso.service';
// import { dataCursos } from './dataCursos';

@Component({
  selector: 'app-curso',
  templateUrl: './curso.component.html',
  styleUrls: ['./curso.component.css']
})
export class CursoComponent implements OnInit {
  cursos: Array<Curso> = [];
  constructor(private cursoService: CursoService) { }


  getCursos()
  {

    this.cursoService.getCursos().subscribe(cursos => {
      this.cursos = cursos;
    });
  }

  getPromedio(cursos: Array<Curso>){
    let cant = 0;
    let suma = 0;
    for (let i in cursos){
      suma += this.cursos[i].seasons;
    }
    cant = suma / this.cursos.length
    return cant;
  }

  ngOnInit() {
    this.getCursos();
    this.getPromedio(this.cursos);
  }

}
