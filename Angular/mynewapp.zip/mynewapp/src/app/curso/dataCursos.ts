import { Curso } from "./curso";

// export const dataCursos = [
//  new Curso("Ingeniería de software", "Martin Fowler", 4),
//  new Curso("Fútbol 1", "Freddy Rincón", 2),
//  new Curso("Algoritmos", "Dennis Ritchie", 2),
//  new Curso("Estructuras de datos", "Yesid Donoso", 2),
//  new Curso("Fútbol 2", "James Rodríguez", 6),
// ];


